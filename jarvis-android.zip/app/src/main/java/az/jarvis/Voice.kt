package az.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/** Səs → mətn (SpeechRecognizer) və mətn → səs (TextToSpeech). Yalnız əsas (main) thread-dən çağırılmalıdır. */
class Voice(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val ttsReady = CompletableDeferred<Boolean>()
    private var recognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                // Azərbaycan dili yoxdursa türk dilinə keçirik (anlaşıla bilən ən yaxın variant)
                val az = Locale("az", "AZ")
                if (t.isLanguageAvailable(az) >= TextToSpeech.LANG_AVAILABLE) {
                    t.language = az
                } else {
                    t.language = Locale("tr", "TR")
                }
                ttsReady.complete(true)
            } else {
                ttsReady.complete(false)
            }
        }
    }

    suspend fun speak(text: String) {
        if (text.isBlank()) return
        if (!ttsReady.await()) return
        val t = tts ?: return
        suspendCancellableCoroutine<Unit> { cont ->
            val id = "u" + System.nanoTime()
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Unit)
                }
            })
            t.speak(text.take(1500), TextToSpeech.QUEUE_FLUSH, null, id)
            cont.invokeOnCancellation { t.stop() }
        }
    }

    suspend fun listen(): String? = suspendCancellableCoroutine<String?> { cont ->
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                rec.destroy()
                if (cont.isActive) cont.resume(null)
            }

            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                rec.destroy()
                if (cont.isActive) cont.resume(list?.firstOrNull())
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "az-AZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "az-AZ")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        rec.startListening(intent)
        cont.invokeOnCancellation { rec.destroy() }
    }

    fun shutdown() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
