package az.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Quraşdırma + böyük "Danış" düyməsi + söhbət jurnalı. İnterfeys kodla qurulur (XML yoxdur). */
class MainActivity : Activity() {
    private val cyan = Color.parseColor("#22D3EE")
    private val bg = Color.parseColor("#04101C")
    private val panel = Color.parseColor("#0A2A3C")

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText

    private val logListener: (String) -> Unit = { text ->
        runOnUiThread { if (::logView.isInitialized) logView.text = text }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(cyan)
        background = GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), cyan)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    private fun label(text: String, size: Float = 14f): TextView = TextView(this).apply {
        this.text = text
        setTextColor(cyan)
        textSize = size
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    private fun input(hint: String, secret: Boolean): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#4B7C8F"))
        setTextColor(Color.WHITE)
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(24))
        }

        col.addView(label("J.A.R.V.I.S", 28f).apply {
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            letterSpacing = 0.25f
        })

        // Böyük danışma düyməsi
        val talk = Button(this).apply {
            text = "🎤  Danış"
            isAllCaps = false
            textSize = 22f
            setTextColor(cyan)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(panel)
                setStroke(dp(3), cyan)
            }
            setOnClickListener { startListening() }
            layoutParams = LinearLayout.LayoutParams(dp(180), dp(180)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(20)
                bottomMargin = dp(8)
            }
        }
        col.addView(talk)

        col.addView(CheckBox(this).apply {
            text = "Davamlı söhbət (cavabdan sonra yenə dinlə)"
            setTextColor(cyan)
            isChecked = Prefs.continuous(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> Prefs.setContinuous(this@MainActivity, checked) }
        })
        col.addView(button("⏹ Jarvis-i dayandır") {
            stopService(Intent(this, JarvisService::class.java))
        })

        statusView = label("", 14f).apply { typeface = Typeface.MONOSPACE }
        col.addView(statusView)

        col.addView(label("Quraşdırma", 18f))
        col.addView(button("1. İcazələri ver (mikrofon, kontakt, zəng, SMS)") { requestPerms() })
        col.addView(button("2. Əlçatanlıq xidmətini aç (ekranı idarə etmək üçün)") {
            Toast.makeText(this, "Siyahıdan Jarvis → İşə sal", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3. Başqa tətbiqlərin üstündə göstərmə icazəsi") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("Tətbiq məlumatı (Məhdud ayarlara icazə üçün)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        col.addView(label("Claude API açarı (console.anthropic.com)"))
        keyInput = input("sk-ant-...", true)
        col.addView(keyInput)
        col.addView(label("Model"))
        modelInput = input(Prefs.DEFAULT_MODEL, false).apply { setText(Prefs.model(this@MainActivity)) }
        col.addView(modelInput)
        col.addView(button("Saxla") {
            val k = keyInput.text.toString().trim()
            if (k.isNotEmpty()) Prefs.setApiKey(this, k)
            val m = modelInput.text.toString().trim()
            Prefs.setModel(this, if (m.isEmpty()) Prefs.DEFAULT_MODEL else m)
            keyInput.setText("")
            Toast.makeText(this, "Saxlanıldı", Toast.LENGTH_SHORT).show()
            refreshStatus()
        })

        col.addView(label("Söhbət", 18f))
        logView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            minHeight = dp(160)
            setTextIsSelectable(true)
        }
        col.addView(logView)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        Core.addListener(logListener)
    }

    override fun onPause() {
        Core.removeListener(logListener)
        super.onPause()
    }

    private fun permissionList(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        requestPermissions(permissionList(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        fun mark(ok: Boolean) = if (ok) "✓" else "✗"
        val perms = permissionList().all { granted(it) }
        val acc = JarvisAccessibilityService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        val key = Prefs.apiKey(this).isNotBlank()
        statusView.text = "${mark(perms)} İcazələr\n${mark(acc)} Əlçatanlıq xidməti\n" +
            "${mark(overlay)} Üstündə göstərmə\n${mark(key)} API açarı"
    }

    private fun startListening() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            requestPerms()
            return
        }
        if (Prefs.apiKey(this).isBlank()) {
            Toast.makeText(this, "Əvvəlcə API açarını daxil edib Saxla düyməsinə bas", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java).setAction("LISTEN"))
    }
}
