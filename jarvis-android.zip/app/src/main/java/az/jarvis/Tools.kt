package az.jarvis

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Telefonu idarə edən alətlər. Zəng və SMS kimi həssas əməliyyatlar
 * icra olunmazdan əvvəl səslə təsdiq istəyir (confirm).
 */
class Tools(
    private val ctx: Context,
    private val confirm: suspend (String) -> Boolean
) {

    companion object {
        private const val NEED_ACC =
            "Əlçatanlıq xidməti aktiv deyil. İstifadəçi onu Jarvis tətbiqindəki addımla aktivləşdirməlidir."

        private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
        private fun num(desc: String) = JSONObject().put("type", "number").put("description", desc)
        private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

        private fun tool(
            name: String,
            desc: String,
            props: JSONObject = JSONObject(),
            required: List<String> = emptyList()
        ): JSONObject = JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "input_schema",
                JSONObject()
                    .put("type", "object")
                    .put("properties", props)
                    .put("required", JSONArray(required))
            )

        fun definitions(): JSONArray {
            val arr = JSONArray()
            arr.put(
                tool(
                    "open_app",
                    "Open an installed app by its launcher label (e.g. WhatsApp, Camera, Settings, Chrome, Maps). Labels may be in English or Azerbaijani.",
                    JSONObject().put("name", str("App name")),
                    listOf("name")
                )
            )
            arr.put(
                tool(
                    "read_screen",
                    "Read the visible texts and buttons of the app currently on screen. Needed before tapping or typing."
                )
            )
            arr.put(
                tool(
                    "tap",
                    "Tap a button, link or item on screen that contains the given text or content description.",
                    JSONObject().put("text", str("Visible text or description of the element")),
                    listOf("text")
                )
            )
            arr.put(
                tool(
                    "type_text",
                    "Type text into the focused (or first) input field on screen. Set submit=true to press the keyboard Enter/Search key afterwards.",
                    JSONObject().put("text", str("Text to type")).put("submit", bool("Press Enter afterwards")),
                    listOf("text")
                )
            )
            arr.put(
                tool(
                    "press",
                    "System navigation: go back, go home, open recent apps, open notifications or quick settings, or scroll the current screen.",
                    JSONObject().put(
                        "action",
                        str("One of: back, home, recents, notifications, quick_settings, scroll_down, scroll_up")
                    ),
                    listOf("action")
                )
            )
            arr.put(
                tool(
                    "find_contact",
                    "Look up phone numbers of contacts by name.",
                    JSONObject().put("name", str("Contact name or part of it")),
                    listOf("name")
                )
            )
            arr.put(
                tool(
                    "call_contact",
                    "Call a contact or a phone number. The user is asked to confirm by voice first.",
                    JSONObject().put("target", str("Contact name or phone number")),
                    listOf("target")
                )
            )
            arr.put(
                tool(
                    "send_sms",
                    "Send an SMS to a contact or number. The user is asked to confirm by voice first.",
                    JSONObject().put("to", str("Contact name or phone number")).put("message", str("Message text")),
                    listOf("to", "message")
                )
            )
            arr.put(
                tool(
                    "open_url",
                    "Open a web page in the browser. For a web search use https://www.google.com/search?q=<url-encoded query>.",
                    JSONObject().put("url", str("http(s) URL")),
                    listOf("url")
                )
            )
            arr.put(
                tool(
                    "navigate",
                    "Start navigation / show a place on the map.",
                    JSONObject().put("place", str("Place name or address")),
                    listOf("place")
                )
            )
            arr.put(
                tool(
                    "set_alarm",
                    "Set an alarm clock for a time of day (24-hour).",
                    JSONObject().put("hour", num("0-23")).put("minute", num("0-59")).put("label", str("Alarm label")),
                    listOf("hour", "minute")
                )
            )
            arr.put(
                tool(
                    "set_timer",
                    "Start a countdown timer.",
                    JSONObject().put("seconds", num("Duration in seconds")).put("label", str("Timer label")),
                    listOf("seconds")
                )
            )
            arr.put(
                tool(
                    "flashlight",
                    "Turn the flashlight on or off.",
                    JSONObject().put("on", bool("true = on, false = off")),
                    listOf("on")
                )
            )
            arr.put(
                tool(
                    "set_volume",
                    "Set the media volume.",
                    JSONObject().put("percent", num("0-100")),
                    listOf("percent")
                )
            )
            arr.put(tool("phone_status", "Get current date, time and battery level."))
            arr.put(
                tool(
                    "wait",
                    "Wait a few seconds, e.g. for an app or page to finish loading.",
                    JSONObject().put("seconds", num("0.5-8")),
                    listOf("seconds")
                )
            )
            return arr
        }
    }

    suspend fun run(name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(a.getString("name"))
        "read_screen" -> readScreen()
        "tap" -> tap(a.getString("text"))
        "type_text" -> typeText(a.getString("text"), a.optBoolean("submit", false))
        "press" -> press(a.getString("action"))
        "find_contact" -> {
            val list = findContacts(a.getString("name"))
            if (list.isEmpty()) "Tapılmadı." else list.joinToString("; ") { "${it.first}: ${it.second}" }
        }
        "call_contact" -> call(a.getString("target"))
        "send_sms" -> sms(a.getString("to"), a.getString("message"))
        "open_url" -> openUrl(a.getString("url"))
        "navigate" -> navigate(a.getString("place"))
        "set_alarm" -> setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", "Jarvis"))
        "set_timer" -> setTimer(a.getInt("seconds"), a.optString("label", "Jarvis"))
        "flashlight" -> flashlight(a.getBoolean("on"))
        "set_volume" -> setVolume(a.getInt("percent"))
        "phone_status" -> phoneStatus()
        "wait" -> {
            delay((a.optDouble("seconds", 1.0).coerceIn(0.5, 8.0) * 1000).toLong())
            "Gözlədi."
        }
        else -> "Naməlum alət: $name"
    }

    // ---------- köməkçilər ----------

    private fun acc() = JarvisAccessibilityService.instance

    private fun hasPerm(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun startNew(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ---------- tətbiqlər və naviqasiya ----------

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val q = name.trim()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(q, ignoreCase = true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(q, ignoreCase = true) }
            ?: return "'$name' adlı tətbiq tapılmadı."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Tətbiq açıla bilmədi."
        startNew(intent)
        return "${match.loadLabel(pm)} açıldı."
    }

    private fun openUrl(url: String): String {
        var u = url.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        startNew(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        return "Səhifə açıldı."
    }

    private fun navigate(place: String): String {
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            i.setPackage("com.google.android.apps.maps")
            startNew(i)
            "Naviqasiya başladı."
        } catch (e: Exception) {
            startNew(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
            "Xəritədə göstərildi."
        }
    }

    // ---------- ekranı oxumaq və idarə etmək ----------

    private fun readScreen(): String {
        val svc = acc() ?: return NEED_ACC
        val root = svc.rootInActiveWindow ?: return "Ekran oxuna bilmədi."
        val sb = StringBuilder("Tətbiq: ${root.packageName}\n")
        var count = 0

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count >= 150 || !n.isVisibleToUser) return
            var t = n.text?.toString()?.takeIf { it.isNotBlank() }
                ?: n.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            if (n.isPassword) t = "[gizli sahə]"
            if (t != null || n.isEditable) {
                val flags = ArrayList<String>()
                if (n.isClickable) flags.add("click")
                if (n.isEditable) flags.add("input")
                if (n.isScrollable) flags.add("scroll")
                if (n.isChecked) flags.add("checked")
                sb.append("- \"").append(t?.take(100) ?: "").append("\" ")
                    .append(flags.joinToString(",")).append("\n")
                count++
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    private fun tap(text: String): String {
        val svc = acc() ?: return NEED_ACC
        val root = svc.rootInActiveWindow ?: return "Ekran oxuna bilmədi."
        val nodes = root.findAccessibilityNodeInfosByText(text)
        if (nodes.isNullOrEmpty()) return "'$text' ekranda tapılmadı."
        val n = nodes.firstOrNull { it.isVisibleToUser } ?: nodes[0]

        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Toxunuldu: $text"

        val r = Rect()
        n.getBoundsInScreen(r)
        return if (svc.tapAt(r.centerX().toFloat(), r.centerY().toFloat())) {
            "Toxunuldu: $text"
        } else {
            "Toxuna bilmədi."
        }
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val f = findEditable(n.getChild(i))
            if (f != null) return f
        }
        return null
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) {
            val f = findScrollable(n.getChild(i))
            if (f != null) return f
        }
        return null
    }

    private fun typeText(text: String, submit: Boolean): String {
        val svc = acc() ?: return NEED_ACC
        val root = svc.rootInActiveWindow ?: return "Ekran oxuna bilmədi."
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
        val target = focused ?: findEditable(root) ?: return "Mətn sahəsi tapılmadı."
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return if (ok) "Yazıldı." else "Yaza bilmədi."
    }

    private fun press(action: String): String {
        val svc = acc() ?: return NEED_ACC
        val ok = when (action) {
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "scroll_down", "scroll_up" -> {
                val n = findScrollable(svc.rootInActiveWindow)
                n?.performAction(
                    if (action == "scroll_down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                ) ?: false
            }
            else -> return "Naməlum əmr: $action"
        }
        return if (ok) "Oldu." else "Alınmadı."
    }

    // ---------- kontaktlar, zəng, SMS ----------

    private fun findContacts(name: String): List<Pair<String, String>> {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(nameCol, numCol),
            "$nameCol LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c ->
            while (c.moveToNext() && out.size < 5) out.add(Pair(c.getString(0) ?: "", c.getString(1) ?: ""))
        }
        return out
    }

    /** Ad və ya nömrədən (görünən ad, nömrə) cütü qaytarır. */
    private fun resolveNumber(target: String): Pair<String, String>? {
        val t = target.trim()
        if (t.matches(Regex("[+0-9 ()-]{3,}"))) return Pair(t, t)
        return findContacts(t).firstOrNull()
    }

    private suspend fun call(target: String): String {
        if (!hasPerm(Manifest.permission.CALL_PHONE)) return "Zəng icazəsi verilməyib."
        val (label, number) = resolveNumber(target) ?: return "'$target' kontaktı tapılmadı."
        if (!confirm("$label nömrəsinə zəng edim? Bəli, ya yox.")) return "İstifadəçi imtina etdi."
        startNew(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
        return "$label zəng edilir."
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private suspend fun sms(to: String, message: String): String {
        if (!hasPerm(Manifest.permission.SEND_SMS)) return "SMS icazəsi verilməyib."
        val (label, number) = resolveNumber(to) ?: return "'$to' kontaktı tapılmadı."
        if (!confirm("$label şəxsinə bu mesajı göndərim: $message. Bəli, ya yox.")) return "İstifadəçi imtina etdi."
        val sm = smsManager()
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(message), null, null)
        return "SMS göndərildi."
    }

    // ---------- saat, səs, fənər, status ----------

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        startNew(i)
        return "Zəngli saat %d:%02d üçün quruldu.".format(hour, minute)
    }

    private fun setTimer(seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        startNew(i)
        return "Taymer $seconds saniyə üçün başladı."
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Fənər tapılmadı."
        cm.setTorchMode(id, on)
        return if (on) "Fənər yandı." else "Fənər söndü."
    }

    private fun setVolume(percent: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = percent.coerceIn(0, 100)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * p / 100, 0)
        return "Səs $p% oldu."
    }

    private fun phoneStatus(): String {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return "Vaxt: $now, batareya: ${if (pct >= 0) "$pct%" else "məlum deyil"}"
    }
}
