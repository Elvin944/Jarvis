package az.jarvis

import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList

/** Ekranda göstərilən söhbət jurnalı. */
object Core {
    private val history = StringBuilder()
    private val listeners = CopyOnWriteArrayList<(String) -> Unit>()

    fun addListener(l: (String) -> Unit) {
        listeners.add(l)
        l(snapshot())
    }

    fun removeListener(l: (String) -> Unit) {
        listeners.remove(l)
    }

    @Synchronized
    fun snapshot(): String = history.toString()

    fun log(line: String) {
        val text: String
        synchronized(this) {
            history.append(line).append("\n\n")
            if (history.length > 8000) history.delete(0, history.length - 6000)
            text = history.toString()
        }
        for (l in listeners) l(text)
    }
}

/** Sadə yerli ayarlar (yalnız bu telefonda saxlanılır). */
object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun model(c: Context): String = sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()

    fun continuous(c: Context): Boolean = sp(c).getBoolean("continuous", false)
    fun setContinuous(c: Context, v: Boolean) = sp(c).edit().putBoolean("continuous", v).apply()
}
