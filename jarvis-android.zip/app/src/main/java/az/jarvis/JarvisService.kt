package az.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Mikrofon tipli ön plan xidməti: Jarvis başqa tətbiqi idarə edərkən də dinləyə,
 * danışa və təsdiq soruşa bilsin deyə arxa planda yaşayır.
 * Bildirişdəki "Danış" düyməsi ilə yenidən dinləməyə başlayır.
 */
class JarvisService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var voice: Voice
    private lateinit var agent: Agent
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        voice = Voice(this)
        agent = Agent(this, Tools(this) { question -> confirm(question) })
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "LISTEN" -> startTurn()
            "STOP" -> {
                job?.cancel()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        voice.shutdown()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun serviceIntent(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, JarvisService::class.java).setAction(action), flags
        )

        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val talk = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Danış", serviceIntent("LISTEN", 1)
        ).build()
        val stop = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dayandır", serviceIntent("STOP", 2)
        ).build()

        val notification = Notification.Builder(this, "jarvis")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText("Hazıram — \"Danış\" düyməsinə bas")
            .setContentIntent(open)
            .addAction(talk)
            .addAction(stop)
            .setOngoing(true)
            .build()

        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, 1, notification, type)
    }

    private fun startTurn() {
        job?.cancel()
        job = scope.launch {
            do {
                Core.log("🎤 Dinləyirəm…")
                val heard = voice.listen()
                if (heard.isNullOrBlank()) {
                    Core.log("(səs eşidilmədi)")
                    break
                }
                Core.log("Sən: $heard")
                if (isStopPhrase(heard)) {
                    voice.speak("Yaxşı, dayandım.")
                    break
                }
                val reply = try {
                    agent.run(heard)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "Xəta: ${e.message}"
                }
                Core.log("Jarvis: $reply")
                voice.speak(reply)
            } while (Prefs.continuous(this@JarvisService))
        }
    }

    private fun isStopPhrase(s: String): Boolean {
        val t = s.trim().lowercase().trimEnd('.', '!', '?', ' ')
        return t in setOf("dayan", "stop", "bəsdir", "sağ ol", "sağol", "çıx")
    }

    /** Həssas əməliyyatdan əvvəl səslə "bəli/yox" soruşur. */
    private suspend fun confirm(question: String): Boolean {
        Core.log("❓ $question")
        voice.speak(question)
        val answer = voice.listen()?.lowercase() ?: return false
        Core.log("Təsdiq cavabı: $answer")
        val words = answer.split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }.toSet()
        val no = setOf("yox", "xeyr", "no", "dayan", "ləğv", "olmaz", "istəmirəm", "etmə")
        val yes = setOf("hə", "he", "bəli", "beli", "yes", "oldu", "ok", "okay", "təsdiq", "göndər", "et", "yaxşı", "əlbəttə")
        if (words.any { it in no }) return false
        return words.any { it in yes }
    }
}
